
package TryCatchFinally;

import java.io.File;

class Operation
{
    void msg1()
    {
        int x = 10;
        int y = 0; 
        try{
         int result =x/y;
        }
        catch(ArithmeticException e)
        {
          System.out.println(e);
        }
        finally{
           System.out.println("x: "+x+"\ny: "+y);
        }
    }
    void msg2()
    {
        try
        {
            String name = null;
            System.out.println(name.charAt(4));
        }
        catch(NullPointerException e)
        {
            System.out.println(e);
        }
    }
    void msg3()
    {
        try{
            String name = "ritu";
            System.out.println(name.charAt(10));
        }
        catch(StringIndexOutOfBoundsException e)
        {
            System.out.println(e);
        }
    }
    void msg4()
    {
        try{
            int[] array = {1,2,3};
            System.out.println(array[5]);
        }
        catch(ArrayIndexOutOfBoundsException e)
        {
            System.out.println(e);
        }
    }
    void msg5()
    {
        try
        {
             int num = Integer.parseInt("ritu");
        }
        catch(NumberFormatException e)
        {
            System.out.println(e);
        }
    }
    void msg6()
    {
        try{
            File f = new File("D://file.txt");
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }
}

public class Demo1 {
    public static void main(String args[])
    {
        Operation p = new Operation();
        p.msg1();
        p.msg2();
        p.msg3();
        p.msg4();
        p.msg5();  
        p.msg6();
    }
}
