
package Abstraction;

/*
A class which is declared with the abstract keyword 
is known as an abstract class in Java. 
It can have abstract and non-abstract methods 
(method with the body).

Abstruction:Abstraction is a process of hiding 
the implementation details and showing only 
functionality to the user.

rules:
-An abstract class must be declared with an abstract keyword.
-It can have abstract and non-abstract methods.
-It cannot be instantiated.
-It can have constructors and static methods also.
-It can have final methods 
*/

public class define {
    
}
