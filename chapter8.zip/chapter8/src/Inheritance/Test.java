
package Inheritance;



public class Test {
    public static void main(String[] agrs)
    {
        Teacher t1 = new Teacher();
        t1.setName("ritu");
        t1.setAddress("dhaka");
        t1.setAge(21);
        t1.setCountry("bangladeshi");
        t1.setGender("female");
        t1.setId(13232);
        t1.setInstitution("Cou");
        t1.setMobile(1209380198);
        t1.setReligion("islam");
        
        t1.printinfo();
       
    }
    
    
}
