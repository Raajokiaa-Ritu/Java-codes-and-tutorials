
package other;
/*
Java Math class provides several methods to work 
on math calculations like min(), max(), avg(), 
sin(), cos(), tan(), round(), ceil(), floor(), abs() etc.

*/

public class MathDemo {
    public static void main(String args[])
    {
        double a = 2;
        double b = 5;
        System.out.println(Math.max(a, b));
        System.out.println(Math.min(a, b));
        System.out.println(Math.sqrt(a));
        System.out.println(Math.pow(a, b));
        System.out.println(Math.log(a));
        System.out.println(Math.log10(a));
        
        
        
    }
}
