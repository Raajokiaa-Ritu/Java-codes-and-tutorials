
package StringClass;

public class BufferDemo {
    public static void main(String args[])
    {
        StringBuffer sb = new StringBuffer("java");
        System.out.println(sb);
        sb.append(" coding ");
        sb.append(8.5);
        System.out.println(sb);
        sb.reverse();
        System.out.println(sb);
    }
}
