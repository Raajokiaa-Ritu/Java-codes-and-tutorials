
package AccessModifiers;
/*
There are four types of Java access modifiers:
-public
-private
-protected
-default

Private: The access level of a private modifier is 
only within the class. It cannot be accessed from 
outside the class.
*/
class A
{
    private int data=11;
    private void msg()
    {
        System.out.println("private method");
    }
    private A(){ };//private constructor
    
    
}
public class PrivateDemo {
    public static void main(String args[])
    {
        /*
        A ob = new A(); //can't access private constructor
       
        System.out.println(ob.data);//error
        ob.msg();//error
        */
        
    }
}
