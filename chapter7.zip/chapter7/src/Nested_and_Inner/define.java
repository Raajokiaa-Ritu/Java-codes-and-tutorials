
package Nested_and_Inner;


public class define {
/*
Java inner class or nested class is a class 
that is declared inside the class or interface.
syntax:
class Outer
{
    class Innter
    {
    
    }
}    
*/
}
