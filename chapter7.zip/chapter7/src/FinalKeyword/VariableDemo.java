
package FinalKeyword;

class University
{
 final String VERSITY = "CoU"; //final varible,not changable
 final int FEE; 
 //blank final varible
 //this can be initialize using only constructor
 
  static final String DEPT;
 //static blank final varible,this can be initialize only static block
 
 University()
 {
      FEE= 1000;
 }

 static
 {
     DEPT = "cse";
 }
 
 void getinfo()
 {
   System.out.println(VERSITY+" "+FEE+" "+DEPT);
 }
}

public class VariableDemo {
    public static void main(String args[])
    {
        University ob = new University();
        ob.getinfo();
    }
}
