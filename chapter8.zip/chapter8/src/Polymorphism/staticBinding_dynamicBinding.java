
package Polymorphism;

/*

static binding:when type of the object is determined
at compiled time,is static binding.
syntax:same as method overloading

dynamic binding:when type of the object is determined
at run time,is dynamic binding.
syntax:same as method overriding
*/

public class staticBinding_dynamicBinding {
    
}
