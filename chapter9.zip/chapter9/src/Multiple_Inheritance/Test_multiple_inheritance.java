
package Multiple_Inheritance;

interface Student
{
 public abstract void eat();
}
interface Person
{
 public abstract void eat();
}
class Employee implements Student,Person
{
    @Override
    public void eat()
    {
     System.out.println("employee is a student");
    }
}

public class Test_multiple_inheritance {
    
    public static void main(String[] args)
    {
        Employee e = new Employee();
        e.eat();
    }
            
    
    
}
