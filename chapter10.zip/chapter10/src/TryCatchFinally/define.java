
package TryCatchFinally;

/*

An exception is a run-time error.
Java try block is used to enclose the code that might throw an exception. 
It must be used within the method.
If an exception occurs at the particular statement in the try block,
the rest of the block code will not execute.
Syntax of Java try-catch:
-------------------------
try{    
//code that may throw an exception    
}
catch(Exception_class_Name ref){
}    

Syntax of try-finally block:
---------------------------
try{    
//code that may throw an exception    
}finally{} 
 */
public class define {
    
}
