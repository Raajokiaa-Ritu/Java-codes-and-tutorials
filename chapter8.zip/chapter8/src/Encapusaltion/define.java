
package Encapusaltion;

/*

Encapsulation is a process of
-Packaging variables and methods into a single unit
-protecting data by declaring them as private
Benefit:
1.provide data hiding
2.code reusability
3.code can be modified without breaking the code
4.maintainability:hiding implementation details
reduces complexity.


Data hiding: Declaring private data will be hidden
from other classes and they can only be accessed
through the methods of their currnt class,this
is known as data hiding.

*/
class Computer
{
    private String name;
    private int price;
    public void setName(String name)
    {
        this.name = name;
    }
    public void setPrice(int price)
    {
        this.price =price;
    }
}
public class define {
    
}
