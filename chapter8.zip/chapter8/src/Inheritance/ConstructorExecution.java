
package Inheritance;

class D
{
    D()
    {
      System.out.println("constructor D");
    }
    void msg(){
        System.out.println("inside class D");
    }
}
class E extends D
{
    E()
    {
      System.out.println("constructor E");
    }
    @Override
    void msg(){
        super.msg();
        System.out.println("inside class E");
    }
}
class F extends E
{
    F()
    {
      System.out.println("constructor F");
    }
    @Override
    void msg(){
        super.msg();
        System.out.println("inside class F");
    }
}

public class ConstructorExecution {
    public static void main(String args[])
    {
        F ob = new F();
        
        ob.msg();
    }
}
