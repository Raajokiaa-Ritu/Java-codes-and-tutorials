
package FinalKeyword;

public class Define {
/*
The final keyword in java is used to restrict the user.
-Values	of Linal variables are fixed,
 once the value is assigned then it can’t be modiLied.
-final variables are written in capital letters
-final variable can be initialize while 
 declaring the variable,in a static block or
 using constructors
-final method cannot be override
-final class cannot be extended
    
    
*/    
}
