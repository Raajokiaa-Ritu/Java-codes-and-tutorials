
package Polymorphism;


public class Define {
    
/*
Polymorphism in Java is a concept by which we can perform
a single action in different ways.
    
Polymorphism are 2types
    1.compile time/static binding/method overloading/early binding
    2.run time/dynamic binding/method overriding/late binding

    
    
*/    
    
    
}
