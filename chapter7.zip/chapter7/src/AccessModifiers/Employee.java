
package AccessModifiers;

/*
Public: The access level of a public modifier is everywhere.
It can be accessed from within the class, outside the class, 
within the package and outside the package.
*/
public class Employee
{
    public void msg()
    {
      System.out.println("public class");
    }   
}
