
package Inheritance;

class X
{
    
}
class Y extends X
{
    
}
class Z extends X
{
    
}
public class HierarchicalDemo {
    
}
