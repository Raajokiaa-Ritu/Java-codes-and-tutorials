
package PackageDemo;

import java.util.Scanner;
import java.util.Arrays;
import Multiple_Inheritance.Cat;
import Multiple_Inheritance.*;


//import java.util.*;

public class Animal {
    
    public static void main(String[] args)
    {
      Scanner input = new Scanner(System.in);   
      String name;
      name = input.nextLine();
      
      System.out.println(name);
      
      Cat c = new Cat();
      c.msg();
      //------------
      Multiple_Inheritance.Cat obj = new Multiple_Inheritance.Cat();
      obj.msg();
      
    }
    
}
