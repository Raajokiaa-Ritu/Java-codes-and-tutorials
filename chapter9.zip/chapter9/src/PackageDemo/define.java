
package PackageDemo;

/*
A java package is a group of similar types of classes, 
interfaces and sub-packages.
-1. Java package is used to categorize the classes and 
interfaces so that they can be easily maintained.
-2. Java package provides access protection.
-3. Java package removes naming collision.
*/
public class define {
    
}
