
package FinalKeyword;
final class Person
{
  String name;
  Person()
  {
     System.out.println("this is final class");  
  }
}
//final class cannot be extended/inherited
//class Student extends Person{ }--->wrong

public class ClassDemo {
    
    public static void  main(String [] args)
    {
        Person p1 = new Person();
        
    }
    
    
}
