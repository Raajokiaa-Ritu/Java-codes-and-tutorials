
package StringClass;


public class BuilderDemo {
    public static void main(String argsp[])
    {
        StringBuilder s = new StringBuilder("abc");
        System.out.println(s);
        s.append(" def");
        System.out.println(s);
    }
}
