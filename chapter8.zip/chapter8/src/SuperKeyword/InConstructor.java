
package SuperKeyword;

class Apps {
    int size;
    String color;
    Apps(){   
     System.out.println("inside Apps class");   
    }
    Apps(String color,int size){
        this.color = color;
        this.size = size;
    }
    void getinfo(){
     System.out.println("Apps color = "+color);
     System.out.println("Apps size  = "+size);
    }
}
class Facebook extends Apps{  
    int userNum;
    Facebook(){  
     super();   
     System.out.println("inside Facebook class");   
     //super(); first e na dile error ashbe
    }
    Facebook(String color,int size,int userNum){
        super(color,size);
        this.userNum = userNum;
    }
    @Override
    void getinfo(){
        super.getinfo();
        System.out.println("Apps user = "+userNum);
    }
}

public class InConstructor{
    
    public static void main(String[] args)
    {
        Facebook ob1 = new Facebook();
        Facebook ob2 = new Facebook("blue",1024,3000000);
        
        ob2.getinfo();
       
    }
    
    
    
}
