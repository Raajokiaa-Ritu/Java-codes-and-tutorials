
package StringClass;

public class StringDemo {
   public static void main(String args[])
   {
       String s1 ="RITU";
       String s2 = new String("abcd");
       char[] s3 = {'a','b','c'};
       System.out.println(s1);
       System.out.println(s2);
       System.out.println(s3);
     
       System.out.println(s1.charAt(2));
       
       System.out.println(s1.length());
       System.out.println(s1.equals(s3));
       System.out.println(s1.concat(s2));
       System.out.println(s1.isEmpty());
       System.out.println(s1.toUpperCase());
       System.out.println(s1.toLowerCase());
       
   }
}
