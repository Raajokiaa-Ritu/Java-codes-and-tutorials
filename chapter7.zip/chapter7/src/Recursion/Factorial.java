
package Recursion;
/*
-Recursion is the process of
 defining something in terms of itself.
-A method that calls itself is said to be recursive.
*/
class Operation
{
    int factorial(int n)
    {
        if(n==1)return 1;
        else
        {
            return n*factorial(n-1);
        }
    }
}

public class Factorial {
    public static void main(String args[])
    {
        Operation f = new Operation();
        System.out.println(f.factorial(5));
    }
}
