
package AccessModifiers;

/*
The protected access modifier is accessible within package .
it can be used outside the package using inheritance only

*/
class B
{
    protected void msg()
    {
      System.out.println("b class");
    }
}

public class ProtectedDemo {
    public static void main(String args[])
    {
        B ob = new B();
        ob.msg();
    }
}
