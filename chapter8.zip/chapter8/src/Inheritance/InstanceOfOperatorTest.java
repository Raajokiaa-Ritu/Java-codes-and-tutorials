
package Inheritance;

class Animal1
{
    
}
class Person1 extends Animal1
{
  
}
class Teacher1 extends Person1
{
    
}

public class InstanceOfOperatorTest {
    
    public static void main(String[] args)
    {
     Animal1 a1 = new Animal1();
     Person1 p1 = new Person1();
     Teacher1 t1 = new Teacher1();
     System.out.println(a1 instanceof Animal1);
     System.out.println(p1 instanceof Animal1);
     System.out.println(t1 instanceof Person1);
     System.out.println(t1 instanceof Animal1);
     System.out.println(p1 instanceof Teacher1);
     System.out.println(a1 instanceof Teacher1); 
     
     
     
    }
    
    
}
