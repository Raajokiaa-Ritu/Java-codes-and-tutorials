
package AccessModifiers;


public class PublicDemo {
    public static void main(String args[])
    {
        Employee e = new Employee();
        e.msg();
    }
       
}
