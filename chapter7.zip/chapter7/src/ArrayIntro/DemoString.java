
package ArrayIntro;

public class DemoString {
    public static void main(String args[])
    {
        String[] array = new String[5];
        array[0]= "a";
        array[1]= "ab";
        array[2]= "abc";
        array[3]= "abcd";
        array[4]= "abcde";
        for(String i:array)
        {
         System.out.println(i);
        }
        System.out.println(array.length);
    }
    
}
