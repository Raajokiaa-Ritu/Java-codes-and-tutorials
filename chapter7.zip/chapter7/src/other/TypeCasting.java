
package other;

public class TypeCasting {
    public static void main(String args[])
    {
        //converting an integer result to double result
        int num1,num2;
        num1 = 10;
        num2 = 3;
        
        double result = (double)num1/num2;
        System.out.println("result : "+result);
    }
    
}
