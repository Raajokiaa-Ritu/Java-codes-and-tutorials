
package SuperKeyword;

class A
{
    int x=10;
}
class B extends A
{
    int x = 5;
    void getinfo()
    {
     System.out.println(x); //subclass variable
     System.out.println(super.x); //superclass variable
    }
}

public class InInstanceVariable {
    
    public static void main(String[] args)
    {
        B ob = new B();
        ob.getinfo();
    }  
}

