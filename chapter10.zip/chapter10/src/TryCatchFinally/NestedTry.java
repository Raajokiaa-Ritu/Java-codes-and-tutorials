
package TryCatchFinally;

class Test
{
    int x = 5;
    int y = 0;
    String name = null;
    void msg()
    {
        try{
            try{
              int r = x/y;
              System.out.println(r);
            }
            catch(ArithmeticException e)
            {
                System.out.println(e);
            }
            
            System.out.println(name.charAt(0));
        }
        catch(NullPointerException e)
        {
            System.out.println(e);
        }        
    }
}

public class NestedTry {
    public static void main(String args[])
    {
      Test t = new Test();
      t.msg();
    }
}
