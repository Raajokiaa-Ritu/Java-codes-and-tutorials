package ThrowThrows;

public class Demo1 {
    static int area(int l,int b)throws Exception
    {    
        if(l<0 || b<0)
            throw new Exception();
        return l*b;
    }
    static void fun1()
    {
        try{
            System.out.println(area(-2,3));
        }
        catch(Exception e)
        {
            System.out.println(e);
        }   
    }
    public static void main(String[] args)
    {
        fun1();
    }
}
