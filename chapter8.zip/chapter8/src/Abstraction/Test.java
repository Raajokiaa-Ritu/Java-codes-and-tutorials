
package Abstraction;

abstract class A{
    abstract void message();
}
class B extends A
{
    @Override
    void message()
    {
      System.out.println("hi,from B");
    }
}
class C extends A
{
   @Override
    void message()
    {
        System.out.println("hi,from C");
    }  
}
public class Test {
    
    public static void main(String[] args)
    {
      A ob ;
      ob = new B();
      ob.message();
      
      ob = new C();
      ob.message();
      
    }
    
}
