
package ArgumentPassing;
/*
->If we call a method by passing primitive data then it is
  called call-by-value
->the value is copied to a method parameter
->changes to that formal parameter doesn't affect the actual\
  parameter
->in call-by-value original value doesn't change

*/
class Operation
{
    int data = 50;
    void change(int data)
    {
       data = data+100;
        //changes will be in the local variable
    }
}


public class Call_By_Value {
    
    public static void main(String[] args)
    {
        Operation op = new Operation();
        System.out.println("before : "+op.data);
        
        op.change(500);
        System.out.println("after  : "+op.data);
    }
    
    
    
}
