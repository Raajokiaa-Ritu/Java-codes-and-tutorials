
package InterfaceDefine;

/*
Interface:
1.it has only abstract method
2.it support multiple inheritance
3.fully abstract
4.can only have static and final variable
5.ex: 
interface Animal{
   void eat();
}

Abstract class:
1.can have abstract and non-abstract
2.it doesn't support multiple inheritance
3.can have static,final and instance variable
4.partial abstraction
5.ex:
abstract class Animal{
   abstract void eat();
}

*/

public class abstractClass_vs_Interface {
    
    
    
}
