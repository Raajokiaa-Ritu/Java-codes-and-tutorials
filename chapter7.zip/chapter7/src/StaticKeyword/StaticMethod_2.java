
package StaticKeyword;
class Demo
{
    int x = 10;//non-static variable
    static int y = 12;
    void display1()
    {
      System.out.println("non-static method");
    }
    static void display2()
    {
       System.out.println("static method"); 
    }
    static void display3()
    {
        //display1();//cannot access
        display2();
        //System.out.println(x);//cannot access
        System.out.println(y);
    }
    
}

public class StaticMethod_2 {
    public static void main(String args[])
    {
        Demo.display3();
    }
}
