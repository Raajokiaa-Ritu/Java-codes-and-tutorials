
package Inheritance;

/*
Inheritance in java is a mechanism in which one object
acquires all the properties and behaviors of a parent
object.
it is an important part of OOPs.
Use:
-code reusablity
-method overrriding
-IS-A relation/ parent-child relationship

Syntax:
class BaseClass
{

}
class Derived extends BaseClass
{
    //method and fields
}

In java 3 types of inheritance:
-single
-multilevel
-hierarchical

*/
public class define {
    
}
