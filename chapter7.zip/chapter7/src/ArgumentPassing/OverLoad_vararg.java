
package ArgumentPassing;

class Counter
{
    static void Test(int...num)
    {
        for(int i:num)
            System.out.print(i+" ");
        System.out.println();
    }
    static void Test(boolean...num)
    {
        for(boolean i:num)
            System.out.print(i+" ");
        System.out.println();
    }
    static void Test(String st,int...num)
    {
        System.out.print(st+" ");
        for(int i:num)
            System.out.print(i+" ");
        System.out.println();
    }
}
public class OverLoad_vararg {
    public static void main(String args[])
    {
        Counter.Test(1,2,3,4);
        Counter.Test(true,false,true);
        Counter.Test("testing method",2,3,4);
        
    }
}
