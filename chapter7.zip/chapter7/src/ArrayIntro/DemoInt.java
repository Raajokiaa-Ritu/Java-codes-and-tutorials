
package ArrayIntro;

public class DemoInt {
    public static void main(String args[])
    {
        int[] array = new int[10];
        String[] st = new String[5];
        int[][] ar = new int[5][5];
        
        for(int i=0;i<10;i++)
        {
            array[i] = i+10;
        }
        for(int i:array)//for each loop
        {
         System.out.println(i);
        }
        System.out.println(array.length);
    }
}
