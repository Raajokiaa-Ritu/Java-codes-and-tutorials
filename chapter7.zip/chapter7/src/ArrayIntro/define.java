
package ArrayIntro;

/*
->an array is a collection of similar type of elements 
  which has contiguous memory location.
Java array is an object which contains elements of a similar data type.

advantage:
-code optimization
-random access

dis-ad:
-limited size
*/
public class define {
    
}
