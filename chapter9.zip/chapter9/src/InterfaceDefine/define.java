
package InterfaceDefine;

/*
An interface in Java is a blueprint of a class. 
It has static constants and abstract methods.
The interface in Java is a mechanism to achieve abstraction. 
There can be only abstract methods in the Java interface, 
not method body.
It is used to achieve abstraction and multiple inheritance in Java.
Java Interface also represents the IS-A relationship.
It cannot be instantiated just like the abstract class.

use of interface:
----------------
-It is used to achieve abstraction.
-By interface, we can support the functionality of multiple inheritance.
-It can be used to achieve loose coupling.

syntax:
interface <interface_name>{  
      
    // declare constant fields  
    // declare methods that abstract   
    // by default.  
}  

Relation between class and interface:
-------------------------------------
-class extends class
-interface extends class
-class implements an interface
syntax:
interface A
 { 

 }
class B implements A
 {

 }

*/
public class define {
/*
Interface vs class
    Interface:
    1.interface cannot be instantiated
    2.it does not contains constructor
    3.all methods in interface are abstract
    4.it can't have instance variables
    5.it can implements multiple inheritance
    
   
    
    
*/    
}
