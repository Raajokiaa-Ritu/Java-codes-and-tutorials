
package Nested_and_Inner;

class Outer
{
    int x = 10;
    class Inner
    {
        int y=20;
        void innerInfo()
        {
         System.out.println(x);
         System.out.println(y);
        }
    }
    void outerInfo()
    {
        Inner i = new Inner();
        i.innerInfo();
        System.out.println(i.y);
    }
    
}


public class DemoInnerClass {
    public static void main(String args[])
    {
        Outer ob = new Outer();
        ob.outerInfo();
        
        Outer.Inner i = new Outer().new Inner();
        i.innerInfo();
        
    }
}
