
package ArgumentPassing;

/*
If we pass object in place of any primitive value, 
original value will be changed.
-if we call a method by passing an object then it is
called call by reference
-changes to that formal parameter doest affect the acutal
parameter
-in call by reference orginal value gets change
*/

class Demo
{
    int data =50;
    void change(Demo op)
    {
        op.data = op.data+100;
    }
}

public class Call_by_Reference {
    public static void main(String args[])
    {
        Demo op = new Demo();
        
        System.out.println("before : "+op.data);
        
        op.change(op);
        
        System.out.println("after : "+op.data);
    }
}
