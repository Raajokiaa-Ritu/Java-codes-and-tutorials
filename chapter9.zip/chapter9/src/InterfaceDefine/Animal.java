
package InterfaceDefine;

//interface er object toyri kora jayna
//interface cannot be instantiated

public interface Animal {
    public static final int X = 10;
    public abstract void eat();
    
    
}
