
package InterfaceDefine;

public class Dog implements Animal {
    
    @Override
    public void eat()
    {
     System.out.println("Dogs eat rice");
             
    }
    
}
