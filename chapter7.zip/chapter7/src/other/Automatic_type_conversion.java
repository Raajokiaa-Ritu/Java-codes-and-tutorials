
package other;
class Conversion
{
    void add(double a ,double b) //autometiclly int -> double convert
    {
        System.out.println("a+b = "+(a+b));
        
    }
    void add(double a,double b,double c)
    {
        System.out.println("a+b+c = "+(a+b+c));
    }
}
public class Automatic_type_conversion {
    
    public static void main(String[] args)
    {
        Conversion ob = new Conversion();
        ob.add(5, 3); //passing integer,so eta automatically double hoye jabe
        ob.add(1,2,3);
    }
    
    
    
}
