
package MethodOverriding;
/*
Method Overloading
-parameter must be different
-it occurs within the same class
-inheritance not involved
-return type may or may not same
-on method does not hide another
syntax:
class A
{
  void change(int n,int m){}
  void change(double n,double m){}
  void change(String n,String m){}
}
*/
/*
Method overriding:
-paramter must be same
-it occurs between two class(sub and super class)
-inheritance in involved
-return type must be same
-child method hides parent another

syntax:
class A
{
   void change(){}
}
class B extends A
{
   @override
   void change(){}
}
*/



public class Overloading_vs_Overriding {
    
}
