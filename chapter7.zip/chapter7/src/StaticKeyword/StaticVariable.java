
package StaticKeyword;
/*
The static keyword in Java is used for memory management mainly.
We can apply static keyword with variables, methods, blocks and nested classes.
The static keyword belongs to the class than an instance 
of the class.
static is related to class not object.
the static can be:
 1.variable(also known as a class variable)
 2.method(also known as a class variable)
 3.block
 4.nested class
*/
/*
The static variable can be used to refer 
to the common property of all objects .
It makes program memory efficient(saves memory).

*/
class Student
{
    String name;
    int roll;
    static String versity="Cou";
    Student(int roll,String name)
    {
        this.roll = roll;
        this.name = name;
    }
    void display()
    {
        System.out.println(roll+" "+name);
    }
}
public class StaticVariable {
    public static void main(String args[])
    {
        Student s1 = new Student(11,"A");
        Student s2 = new Student(12,"B");
        
        s1.display();
        s2.display();
        System.out.println(Student.versity);
    }
}
