
package StaticKeyword;
/*
-Is used to initialize the static data member.
-It is executed before the main method 
*/
class Country
{
    static String name;
    static int population;
    static{
        name = "BANGLADESH";
        population = 121983712;
    }
    static void display()
    {
      System.out.println(name+" "+population);
    }
}

public class StaticBlock {
    public static void main(String args[])
    {
        Country.display();
    }
}
