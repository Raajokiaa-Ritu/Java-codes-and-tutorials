
package Polymorphism;
/*
Runtime polymorphism or Dynamic Method Dispatch is a process 
in which a call to an overridden method is resolved at runtime 
rather than compile-time.
*/
//an exmple of method overriding/dynamic binding/runtime polymorphism
//heirarchical inheritance

class Vicle
{
  void getinfo()
  {
   System.out.println("this is Vicle class");
  }
}
class Train extends Vicle
{
  @Override
  void getinfo()
  {
    System.out.println("this is Train class");   
  }
}
class Car extends Vicle
{
    @Override
    void getinfo()
    {
         System.out.println("this is Car class");
    }
}
public class Dynamic_method_dispatch {
    public static void main(String[] args)
    {
      Vicle ob = new Vicle();
      ob.getinfo();
      
      //this is dynamic method dispatch
      ob = new Train();
      ob.getinfo();
      
      ob = new Car();
      ob.getinfo();
    }
    
    
}
