
package StaticKeyword;
//it is executed before main method
public class StaticBlock_2 {
    static
    {
        System.out.println("static block");
    }
    public static void main(String args[])
    {
        System.out.println("main method");
    }
}
