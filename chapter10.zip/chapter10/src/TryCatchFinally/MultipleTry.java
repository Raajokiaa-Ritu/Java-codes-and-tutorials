
package TryCatchFinally;

class Counter
{
    int x=5;
    int y=0;
    int[] ar = new int[5];
    
    void msg()
    {
        try{
           int r = x/y;
           System.out.println(r);
           System.out.println(ar[5]);
        }
        catch(ArithmeticException e)
        {
        System.out.println(e);
        }
        catch(ArrayIndexOutOfBoundsException e)
        {
          System.out.println(e);
        }
        finally{
            System.out.println(x+" "+y);
        }
    }
    
   
}

public class MultipleTry {
    public static void main(String args[]){
        Counter c = new Counter();
        c.msg();
    }
}
