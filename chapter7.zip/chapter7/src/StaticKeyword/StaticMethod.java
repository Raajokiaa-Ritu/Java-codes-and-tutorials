
package StaticKeyword;
/*
If you apply static keyword with any method, 
it is known as static method.
- a static method is related to class not object
- a static method can be invoked without creating obj
- a static method can access another static variable and static method
- a static method can access static data member and can change the value of it
- a static method can't acces not-static method or variable
-this and super key can't be use in static method  
*/
class Person
{
    static String name;
    static int roll;
    static String versity="CoU";
    static void change()
    {
        versity = "IIT";
    }
    
    static void message(String n,int r)
    {
        name = n;
        roll = r;
    }
    static void getinfo()
    {
        System.out.println(roll+" "+name+" "+versity);
    }
    
    
}


public class StaticMethod {
   public static void main(String args[])
   {
       Person.change();
       Person.message("A", 1);
       Person.getinfo();
       
   }
}
