
package FinalKeyword;

//final method can't be override

class Vicle
{
   final void getinfo()
    {
         System.out.println("this is vicle class");
    }
}

class Car extends Vicle
{
    //final method cannot be ovrriden
    
   void info() 
   {
        this.getinfo();
        super.getinfo();
        System.out.println("this is Car class");
   }
}

public class MethodDemo {
    
    public static void main(String[] args)
    {
         Car ob = new Car();
         
         ob.info();
    }
    
    
}

