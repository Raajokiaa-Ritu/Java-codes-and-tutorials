
package MethodOverriding;
/*
**constructor cannot be overriden
**final method cannot be overriden
**static method cannot be overriden

Declaring  a method in subclass which is allready present
in the superclass,is called method overriding.
-code reuse
-one interface,multiple implementation
-run time polymorphism
*/
class Android
{
    String version;
    String processors;
    
    void getProperties()
    {
      System.out.println("android version = "+version);
      System.out.println("android processors = "+processors);
    }       
           
}
//is-a relation
//vivo is an android phone
class Vivo extends Android
{
    String name;
    int price;
    
    @Override
    void getProperties()
    {
        //super.getProperties();
        System.out.println(version);
        System.out.println(processors);
        System.out.println("android name = "+name);
        System.out.println("android price = "+price);
    }
}

public class TestOverriding {
    
    public static void main(String[] args)
    {
        Vivo ob = new Vivo();
        ob.version = "10";
        ob.processors = "snapdragon 888";
        ob.name = "vivo y12";
        ob.price = 1200;
        ob.getProperties();        
    }
    
}
