
package Nested_and_Inner;

class Outer1
{
    void display()
    {
        class Inner
        {
            void innerInfo()
            {
             System.out.println("inner class");
            }
        }
        Inner i = new Inner();
        i.innerInfo();
    }
}

public class LocalInner {
    public static void main(String args[])
    {
        Outer1 ob = new Outer1();
        ob.display();
    }
}
