
package ToStringMethod;

class Operation
{
    int x;
    int y;
    Operation(int x,int y){
        this.x = x;
        this.y = y;
    }
    @Override
    public String toString()
    {
      return "x: "+x+"\ny: "+y;  
    }
}
public class Test {
    public static void main(String args[])
    {
        Operation p = new Operation(4,5);
        System.out.println(p);
    }
}
