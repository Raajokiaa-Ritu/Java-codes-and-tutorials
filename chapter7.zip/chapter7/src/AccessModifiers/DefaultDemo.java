
package AccessModifiers;
/*
The access level of a default modifier is only within the package.
It cannot be accessed from outside the package.
If you do not specify any access level, it will be the default.

*/
class Student
{
    //default data and method
    int n = 11;
    void msg()
    {
     System.out.println("Student class");
    }
}

public class DefaultDemo {
    public static void main(String args[])
    {
        Student s = new Student();
        s.msg();
    }
}
