
/*
The Exception Handling in Java is one of the powerful mechanism to handle
the runtime errors so that the normal flow of the application can be maintained.
Java provides five keywords that are used to handle the exception-
-try
-catch
-finally
-throw
-throws

*/

public class Define {
    
}
