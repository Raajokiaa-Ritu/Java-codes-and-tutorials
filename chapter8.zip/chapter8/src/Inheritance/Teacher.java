
package Inheritance;



public class Teacher extends Person{
    
    private String institution;
    private String address;
    private int id;
    private int mobile;

    public String getInstitution() {
        return institution;
    }

    public void setInstitution(String institution) {
        this.institution = institution;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getMobile() {
        return mobile;
    }

    public void setMobile(int mobile) {
        this.mobile = mobile;
    }
    
    void printinfo()
    {
     System.out.println("Teacher Information:");
     System.out.println("name    = "+getName());
     System.out.println("address = "+getAddress());
     System.out.println("age     = "+getAge());
     System.out.println("nationality = "+getCountry());
     System.out.println("gender   = "+getGender());
     System.out.println("id       = "+getId());
     System.out.println("institution = "+getInstitution());
     System.out.println("mobile      = "+getMobile());
     System.out.println("religion    = "+getReligion());
    }   
}
