
package Multiple_Inheritance;

public class Cat {
    public void msg()
    {
      System.out.println("cat class");
    }
}
