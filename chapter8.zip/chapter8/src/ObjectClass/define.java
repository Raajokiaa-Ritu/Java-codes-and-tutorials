
package ObjectClass;

/*
The Object class is the parent class of 
all the classes in java by default. 
In other words, it is the topmost class of java.

Some object class:
-public final Class getClass()
-public int hashCode()
-public boolean equals(Object obj)
-public String toString()
-public final void notify()
*/
public class define {
    
}
