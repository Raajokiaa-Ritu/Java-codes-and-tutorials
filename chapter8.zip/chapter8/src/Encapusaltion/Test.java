
package Encapusaltion;

public class Test {
    
    public static void main(String[] args)
    {
     
        Person p1 = new Person();
        p1.setName("ritu");
        
        System.out.println("name = "+p1.getName());
        
        
        p1.setAge(21);
        System.out.println("age  = "+p1.getAge());
        
        
        
    }
    
    
}
