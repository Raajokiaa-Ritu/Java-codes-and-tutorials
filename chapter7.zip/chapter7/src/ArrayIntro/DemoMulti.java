
package ArrayIntro;

public class DemoMulti {
  public static void main(String args[])
  {
      int[][] array = new int[2][3];
      for(int i=0;i<2;i++)
      {
       for(int j=0;j<3;j++)
       {
         array[i][j]=i+10;  
       }
      }
      for(int i[]:array)
      {
          for(int j :i)
          {
           System.out.println(j);
          }
      }
      //lenght of array
      System.out.println(array.length);
  }
}
