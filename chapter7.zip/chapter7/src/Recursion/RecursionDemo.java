
package Recursion;

class Test
{
    int value[];
    Test(int i)
    {
        value = new int[i];
    }
    void printArray(int i)
    {
        if(i==0)return;
        else printArray(i-1);
        System.out.println("["+(i-1)+"] = "+value[i-1]);
    }
}


public class RecursionDemo {
    public static void main(String args[])
    {
        Test ob = new Test(10);
        for(int i=0;i<10;i++)ob.value[i] = i;
        
        ob.printArray(10);
    }
}
