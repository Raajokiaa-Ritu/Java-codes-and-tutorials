
package other;
/*
The wrapper class in Java provides the mechanism
to convert primitive into object and object into primitive.
it has 2 features: 
    - Autoboxing : Primitive->object
    - Unboxing   : object   ->Primitive
*/

public class WrapperDemo {
    public static void main(String args[])
    {
        //primitive -->object:autoboxing
        int x = 30;
        Integer y = Integer.valueOf(x);
        System.out.println(y);
        
        Integer z = x; //Integer.valueOf(x)->autoboxing
        System.out.println(z);
        
        //object ->primitve : unboxing
        Double d = new Double(10.1);
        System.out.println(d);
        //double e = d.doubleValue();
        double e = d ;//d.doubleValue() -->unboxing
        System.out.println(e);
        
        
    }
    
}
